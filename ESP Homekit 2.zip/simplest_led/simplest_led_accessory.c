#include <homekit/homekit.h>
#include <homekit/characteristics.h>
#include <port.h>
#include <Arduino.h>

#define RED_PIN    4   // D2
#define GREEN_PIN  0   // D3
#define BLUE_PIN   2   // D4

bool led_power = false;

homekit_value_t led_on_get() {
    return HOMEKIT_BOOL(led_power);
}

void led_on_set(homekit_value_t value) {
    if (value.format != homekit_format_bool) return;
    led_power = value.bool_value;

    if (!led_power) {
        analogWrite(RED_PIN, 0);
        analogWrite(GREEN_PIN, 0);
        analogWrite(BLUE_PIN, 0);
    }
}

homekit_characteristic_t led_on = HOMEKIT_CHARACTERISTIC_(
    ON, false, .getter=led_on_get, .setter=led_on_set
);

homekit_accessory_t *accessories[] = {
    HOMEKIT_ACCESSORY(
        .id=1,
        .category=homekit_accessory_category_lightbulb,
        .services=(homekit_service_t*[]) {
            HOMEKIT_SERVICE(ACCESSORY_INFORMATION, .characteristics=(homekit_characteristic_t*[]) {
                HOMEKIT_CHARACTERISTIC(NAME, "Rainbow LED"),
                HOMEKIT_CHARACTERISTIC(MANUFACTURER, "Lucas"),
                HOMEKIT_CHARACTERISTIC(SERIAL_NUMBER, "001"),
                HOMEKIT_CHARACTERISTIC(MODEL, "ESP8266-RGB"),
                HOMEKIT_CHARACTERISTIC(FIRMWARE_REVISION, "1.0"),
                HOMEKIT_CHARACTERISTIC(IDENTIFY, NULL),
                NULL
            }),
            HOMEKIT_SERVICE(LIGHTBULB, .primary=true, .characteristics=(homekit_characteristic_t*[]) {
                HOMEKIT_CHARACTERISTIC(NAME, "LED"),
                &led_on,
                NULL
            }),
            NULL
        }),
    NULL
};

homekit_server_config_t config = {
    .accessories = accessories,
    .password = "111-11-111",
    .setupId = "ABCD"
};

void accessory_init() {
    pinMode(RED_PIN, OUTPUT);
    pinMode(GREEN_PIN, OUTPUT);
    pinMode(BLUE_PIN, OUTPUT);
    analogWrite(RED_PIN, 0);
    analogWrite(GREEN_PIN, 0);
    analogWrite(BLUE_PIN, 0);
}
